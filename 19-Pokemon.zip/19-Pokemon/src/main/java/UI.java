public class UI {
    public static void main(String[] args) {

        System.out.println("How would you like to choose your Pokemon?");
        System.out.println("1. Id");
        System.out.println("2. Name");


    }
}
